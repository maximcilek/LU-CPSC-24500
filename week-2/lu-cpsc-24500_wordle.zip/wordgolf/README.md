# Word Golf (Java 25 + JavaFX 25)

Single-player, offline Wordle-like game where lower score wins (golf scoring).

## Requirements
- Java **25**
- Maven **3.9+**

## Run
From the project root:

```bash
mvn clean javafx:run
```

## Notes
- Dictionary is bundled at `src/main/resources/words.txt` (15k+ five-letter words).
- Secret words are filtered to avoid obvious plurals (words ending with `s`).
- Difficulty and mode can be changed any time; starting a new round uses the current selections.
