package com.example.wordgolf;

import com.example.wordgolf.services.DictionaryService;
import com.example.wordgolf.services.SecretWordService;
import com.example.wordgolf.ui.MainController;
import com.example.wordgolf.ui.MainView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * JavaFX entry point for Word Golf.
 */
public final class App extends Application {

    @Override
    public void start(Stage stage) {
        DictionaryService dictionaryService = new DictionaryService("/words.txt");
        SecretWordService secretWordService = new SecretWordService(dictionaryService);

        MainView view = new MainView();
        MainController controller = new MainController(view, dictionaryService, secretWordService);
        controller.initialize();

        Scene scene = new Scene(view.getRoot(), 900, 650);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());

        stage.setTitle("Word Golf");
        stage.setScene(scene);
        stage.setMinWidth(820);
        stage.setMinHeight(600);
        stage.show();

        view.requestKeyboardFocus();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
