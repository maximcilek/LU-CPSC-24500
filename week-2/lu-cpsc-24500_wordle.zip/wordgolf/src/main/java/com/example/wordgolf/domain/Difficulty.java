package com.example.wordgolf.domain;

/**
 * Difficulty selection for secret word generation.
 */
public enum Difficulty {
    /** More vowels (default). */
    NORMAL,
    /** Few vowels and no double letters. */
    HARD,
    /** Few/no vowels, double letters allowed. */
    EXPERT
}
