package com.example.wordgolf.domain;

import java.util.Objects;

/**
 * Immutable game configuration for a round.
 * @param difficulty difficulty selection
 * @param mode game mode selection
 */
public record GameConfig(Difficulty difficulty, GameMode mode) {

    public GameConfig {
        Objects.requireNonNull(difficulty, "difficulty");
        Objects.requireNonNull(mode, "mode");
    }

    /**
     * Default configuration.
     * @return default config
     */
    public static GameConfig defaults() {
        return new GameConfig(Difficulty.NORMAL, GameMode.NORMAL);
    }
}
