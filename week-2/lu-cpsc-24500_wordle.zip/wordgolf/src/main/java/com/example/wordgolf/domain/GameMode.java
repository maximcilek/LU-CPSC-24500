package com.example.wordgolf.domain;

/**
 * Game mode selection.
 */
public enum GameMode {
    /** No timer (default). */
    NORMAL,
    /** 60 seconds per guess. */
    TIMED_60,
    /** 90 seconds per guess. */
    TIMED_90;

    /**
     * Returns the seconds per guess for timed modes; 0 for normal mode.
     * @return seconds per guess
     */
    public int secondsPerGuess() {
        return switch (this) {
            case NORMAL -> 0;
            case TIMED_60 -> 60;
            case TIMED_90 -> 90;
        };
    }

    /**
     * @return whether this mode uses a per-guess timer
     */
    public boolean isTimed() {
        return secondsPerGuess() > 0;
    }
}
