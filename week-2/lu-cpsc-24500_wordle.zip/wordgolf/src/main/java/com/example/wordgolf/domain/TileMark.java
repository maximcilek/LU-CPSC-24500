package com.example.wordgolf.domain;

/**
 * Mark assigned to a tile after evaluating a guess.
 */
public enum TileMark {
    /** Not marked (used for uncovered duplicates and unsubmitted tiles). */
    NEUTRAL,
    /** Letter is not in the secret word (or not eligible due to duplicate rules). */
    GRAY,
    /** Letter is in the secret word but in the wrong position. */
    YELLOW,
    /** Letter is in the secret word and in the correct position. */
    GREEN
}
