package com.example.wordgolf.game;

import com.example.wordgolf.domain.GameConfig;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Core round engine: tracks secret, attempts, and evaluations.
 * This class contains no UI logic.
 */
public final class GameEngine {

    private final int maxAttempts;
    private final GuessEvaluator evaluator;

    private String secret;
    private GameConfig config;

    private int attemptIndex;
    private RoundState state;
    private final List<GuessEvaluation> history = new ArrayList<>();

    /**
     * Creates a new engine.
     * @param evaluator evaluator for guess marking
     * @param maxAttempts maximum number of attempts (typically 6)
     */
    public GameEngine(GuessEvaluator evaluator, int maxAttempts) {
        this.evaluator = Objects.requireNonNull(evaluator, "evaluator");
        if (maxAttempts <= 0) throw new IllegalArgumentException("maxAttempts must be > 0");
        this.maxAttempts = maxAttempts;
        this.state = RoundState.IN_PROGRESS;
    }

    /**
     * Starts a new round.
     * @param secretWord secret word (5 letters)
     * @param config game configuration
     */
    public void startNewRound(String secretWord, GameConfig config) {
        Objects.requireNonNull(secretWord, "secretWord");
        Objects.requireNonNull(config, "config");
        if (secretWord.length() != 5) throw new IllegalArgumentException("Secret must be 5 letters.");
        this.secret = secretWord;
        this.config = config;
        this.attemptIndex = 0;
        this.state = RoundState.IN_PROGRESS;
        this.history.clear();
    }

    /**
     * Submits a guess for evaluation.
     * @param guess guess word (5 letters)
     * @return evaluation result
     * @throws IllegalStateException if round is not in progress or attempts exhausted
     */
    public GuessEvaluation submitGuess(String guess) {
        ensureInProgress();
        if (attemptIndex >= maxAttempts) {
            state = RoundState.FAILED;
            throw new IllegalStateException("No attempts remaining.");
        }
        GuessEvaluation evaluation = evaluator.evaluate(guess, secret);
        history.add(evaluation);
        attemptIndex++;

        if (evaluation.solved()) {
            state = RoundState.SOLVED;
        } else if (attemptIndex >= maxAttempts) {
            state = RoundState.FAILED;
        }
        return evaluation;
    }

    /**
     * Consumes an attempt due to timeout (no evaluation/marks).
     */
    public void timeoutAttempt() {
        ensureInProgress();
        attemptIndex++;
        if (attemptIndex >= maxAttempts) {
            state = RoundState.FAILED;
        }
    }

    /**
     * Ends the round early as a give-up.
     */
    public void giveUp() {
        ensureInProgress();
        state = RoundState.GAVE_UP;
    }

    private void ensureInProgress() {
        if (state != RoundState.IN_PROGRESS) {
            throw new IllegalStateException("Round is not in progress.");
        }
        if (secret == null) {
            throw new IllegalStateException("Round has not been started.");
        }
    }

    /**
     * @return current attempt index (0-based for next guess)
     */
    public int getAttemptIndex() {
        return attemptIndex;
    }

    /**
     * @return maximum attempts per round
     */
    public int getMaxAttempts() {
        return maxAttempts;
    }

    /**
     * @return current round state
     */
    public RoundState getState() {
        return state;
    }

    /**
     * @return secret word (revealed at end of round)
     */
    public String getSecret() {
        return secret;
    }

    /**
     * @return game configuration for this round
     */
    public GameConfig getConfig() {
        return config;
    }

    /**
     * @return immutable history of evaluations
     */
    public List<GuessEvaluation> getHistory() {
        return Collections.unmodifiableList(history);
    }
}
