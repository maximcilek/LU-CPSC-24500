package com.example.wordgolf.game;

import com.example.wordgolf.domain.TileMark;

import java.util.List;
import java.util.Objects;

/**
 * Result of evaluating a guess against the secret word.
 * @param guess the guess word
 * @param marks five marks corresponding to each character in the guess
 * @param greenCount number of GREEN marks
 * @param yellowCount number of YELLOW marks
 * @param solved whether the guess solved the word
 */
public record GuessEvaluation(String guess,
                              List<TileMark> marks,
                              int greenCount,
                              int yellowCount,
                              boolean solved) {

    public GuessEvaluation {
        Objects.requireNonNull(guess, "guess");
        Objects.requireNonNull(marks, "marks");
        if (guess.length() != 5) throw new IllegalArgumentException("Guess must be 5 letters.");
        if (marks.size() != 5) throw new IllegalArgumentException("Marks must have size 5.");
        if (greenCount < 0 || yellowCount < 0) throw new IllegalArgumentException("Counts must be non-negative.");
    }
}
