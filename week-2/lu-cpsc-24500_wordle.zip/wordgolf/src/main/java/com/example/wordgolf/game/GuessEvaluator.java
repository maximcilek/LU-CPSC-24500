package com.example.wordgolf.game;

/**
 * Evaluates a guess and returns marking results.
 */
public interface GuessEvaluator {
    /**
     * Evaluates a guess against a secret word.
     * @param guess guess (5 letters)
     * @param secret secret (5 letters)
     * @return evaluation
     */
    GuessEvaluation evaluate(String guess, String secret);
}
