package com.example.wordgolf.game;

/**
 * State of the current round.
 */
public enum RoundState {
    /** Round is active and accepts guesses. */
    IN_PROGRESS,
    /** Word was solved within the attempt limit. */
    SOLVED,
    /** Attempts exhausted without solving. */
    FAILED,
    /** Player gave up early. */
    GAVE_UP
}
