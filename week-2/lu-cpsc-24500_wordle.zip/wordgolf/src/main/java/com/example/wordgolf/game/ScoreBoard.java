package com.example.wordgolf.game;

/**
 * Simple scoreboard for accumulating points across rounds.
 * Lower is better (golf scoring).
 */
public final class ScoreBoard {
    private int roundsPlayed;
    private int totalScore;

    /**
     * Adds a round score.
     * @param points points for the round (lower is better)
     */
    public void addRound(int points) {
        roundsPlayed++;
        totalScore += points;
    }

    /**
     * @return number of rounds played
     */
    public int getRoundsPlayed() {
        return roundsPlayed;
    }

    /**
     * @return total score (lower is better)
     */
    public int getTotalScore() {
        return totalScore;
    }

    /**
     * Resets the scoreboard.
     */
    public void reset() {
        roundsPlayed = 0;
        totalScore = 0;
    }
}
