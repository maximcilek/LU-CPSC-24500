package com.example.wordgolf.services;

import com.example.wordgolf.domain.TileMark;
import com.example.wordgolf.game.GuessEvaluation;
import com.example.wordgolf.game.GuessEvaluator;

import java.security.SecureRandom;
import java.util.*;

/**
 * Evaluates guesses with the duplicate-letter rules specified by the game:
 * <ul>
 *     <li>GREEN: correct letter and position</li>
 *     <li>YELLOW: correct letter, wrong position</li>
 *     <li>GRAY: letter not in the word at all</li>
 *     <li>For duplicate letters where the secret has fewer occurrences:
 *       <ul>
 *         <li>If one occurrence is GREEN, other duplicate occurrences are left {@link TileMark#NEUTRAL} (uncovered).</li>
 *         <li>If multiple occurrences are candidates for YELLOW but the secret can support fewer, only that many are marked YELLOW,
 *             and which ones are marked is randomized.</li>
 *       </ul>
 *     </li>
 * </ul>
 */
public final class DefaultGuessEvaluator implements GuessEvaluator {

    private final Random random;

    /**
     * Creates an evaluator using a cryptographically-strong RNG for fair randomization.
     */
    public DefaultGuessEvaluator() {
        this(new SecureRandom());
    }

    /**
     * Creates an evaluator with a provided {@link Random} instance.
     * @param random random source
     */
    public DefaultGuessEvaluator(Random random) {
        this.random = Objects.requireNonNull(random, "random");
    }

    @Override
    public GuessEvaluation evaluate(String guess, String secret) {
        Objects.requireNonNull(guess, "guess");
        Objects.requireNonNull(secret, "secret");
        if (guess.length() != 5 || secret.length() != 5) throw new IllegalArgumentException("Words must be 5 letters.");
        String g = guess.toLowerCase(Locale.ROOT);
        String s = secret.toLowerCase(Locale.ROOT);

        List<TileMark> marks = new ArrayList<>(Collections.nCopies(5, TileMark.NEUTRAL));

        // Count letters in secret
        Map<Character, Integer> remaining = new HashMap<>();
        for (int i = 0; i < 5; i++) {
            char c = s.charAt(i);
            remaining.merge(c, 1, Integer::sum);
        }

        // First pass: greens
        for (int i = 0; i < 5; i++) {
            char gc = g.charAt(i);
            if (gc == s.charAt(i)) {
                marks.set(i, TileMark.GREEN);
                remaining.computeIfPresent(gc, (k, v) -> v - 1);
            }
        }

        // Group non-green positions by letter for possible yellows
        Map<Character, List<Integer>> yellowCandidates = new HashMap<>();
        for (int i = 0; i < 5; i++) {
            if (marks.get(i) == TileMark.GREEN) continue;
            char gc = g.charAt(i);
            if (!remaining.containsKey(gc)) {
                // Not in secret at all -> gray
                marks.set(i, TileMark.GRAY);
                continue;
            }
            int count = remaining.getOrDefault(gc, 0);
            if (count <= 0) {
                // Secret has the letter, but occurrences are already consumed by greens/yellows.
                // Per rules, leave uncovered rather than marking gray.
                marks.set(i, TileMark.NEUTRAL);
            } else {
                yellowCandidates.computeIfAbsent(gc, k -> new ArrayList<>()).add(i);
            }
        }

        // Assign yellows with randomized selection when candidates exceed remaining count
        for (Map.Entry<Character, List<Integer>> entry : yellowCandidates.entrySet()) {
            char letter = entry.getKey();
            List<Integer> positions = entry.getValue();
            int available = remaining.getOrDefault(letter, 0);
            if (available <= 0) continue;

            Collections.shuffle(positions, random);
            int toMark = Math.min(available, positions.size());
            for (int i = 0; i < toMark; i++) {
                marks.set(positions.get(i), TileMark.YELLOW);
            }
            // any leftover positions stay NEUTRAL (uncovered)
            remaining.put(letter, Math.max(0, available - toMark));
        }

        int greens = 0;
        int yellows = 0;
        for (TileMark m : marks) {
            if (m == TileMark.GREEN) greens++;
            if (m == TileMark.YELLOW) yellows++;
        }
        boolean solved = greens == 5;

        return new GuessEvaluation(g, List.copyOf(marks), greens, yellows, solved);
    }
}
