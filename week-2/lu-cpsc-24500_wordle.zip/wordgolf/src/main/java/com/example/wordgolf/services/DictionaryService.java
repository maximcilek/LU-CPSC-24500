package com.example.wordgolf.services;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Loads and validates dictionary words from a bundled resource.
 */
public final class DictionaryService {

    private static final Pattern WORD_PATTERN = Pattern.compile("^[a-z]{5}$");

    private final Set<String> words;
    private final List<String> wordList;

    /**
     * Loads a word list from a classpath resource.
     * @param resourcePath resource path (e.g. "/words.txt")
     */
    public DictionaryService(String resourcePath) {
        Objects.requireNonNull(resourcePath, "resourcePath");
        this.words = load(resourcePath);
        this.wordList = List.copyOf(words);
    }

    /**
     * @return immutable set of all dictionary words (lowercase)
     */
    public Set<String> allWords() {
        return Collections.unmodifiableSet(words);
    }

    /**
     * @return list view of all words (useful for random selection)
     */
    public List<String> allWordsList() {
        return wordList;
    }

    /**
     * Validates a user guess.
     * @param guess user guess
     * @return true if guess is a valid 5-letter word in the dictionary
     */
    public boolean isValidGuess(String guess) {
        if (guess == null) return false;
        String g = guess.trim().toLowerCase(Locale.ROOT);
        return WORD_PATTERN.matcher(g).matches() && words.contains(g);
    }

    private static Set<String> load(String resourcePath) {
        InputStream in = DictionaryService.class.getResourceAsStream(resourcePath);
        if (in == null) {
            throw new IllegalStateException("Missing resource: " + resourcePath);
        }
        Set<String> set = new HashSet<>(20000);
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                String w = line.trim().toLowerCase(Locale.ROOT);
                if (WORD_PATTERN.matcher(w).matches()) {
                    set.add(w);
                }
            }
        } catch (IOException e) {
            throw new IllegalStateException("Failed to load word list.", e);
        }
        if (set.size() < 10000) {
            throw new IllegalStateException("Word list must contain at least 10,000 five-letter words. Found: " + set.size());
        }
        return set;
    }
}
