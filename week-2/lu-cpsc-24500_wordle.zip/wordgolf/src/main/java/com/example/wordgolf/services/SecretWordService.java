package com.example.wordgolf.services;

import com.example.wordgolf.domain.Difficulty;

import java.security.SecureRandom;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Selects secret words based on difficulty rules.
 */
public final class SecretWordService {

    private static final Pattern FIVE_LETTERS = Pattern.compile("^[a-z]{5}$");
    private static final Set<Character> VOWELS = Set.of('a', 'e', 'i', 'o', 'u');

    private final DictionaryService dictionaryService;
    private final Random random;

    /**
     * Creates the service.
     * @param dictionaryService dictionary service
     */
    public SecretWordService(DictionaryService dictionaryService) {
        this(dictionaryService, new SecureRandom());
    }

    /**
     * Creates the service with a specified random source.
     * @param dictionaryService dictionary service
     * @param random random source
     */
    public SecretWordService(DictionaryService dictionaryService, Random random) {
        this.dictionaryService = Objects.requireNonNull(dictionaryService, "dictionaryService");
        this.random = Objects.requireNonNull(random, "random");
    }

    /**
     * Picks a secret word that conforms to the difficulty constraints.
     * @param difficulty difficulty
     * @return secret word
     */
    public String pickSecret(Difficulty difficulty) {
        Objects.requireNonNull(difficulty, "difficulty");
        List<String> all = dictionaryService.allWordsList();

        // Try a bounded number of times to find a word that matches constraints.
        // With a large dictionary this is fast and avoids precomputing filtered lists.
        for (int attempts = 0; attempts < 50_000; attempts++) {
            String candidate = all.get(random.nextInt(all.size()));
            if (!FIVE_LETTERS.matcher(candidate).matches()) continue;

            // Secret word rule: avoid obvious plurals.
            if (candidate.endsWith("s")) continue;

            if (!matchesDifficulty(candidate, difficulty)) continue;
            return candidate;
        }
        // Fallback: any non-plural 5-letter word.
        for (int attempts = 0; attempts < 50_000; attempts++) {
            String candidate = all.get(random.nextInt(all.size()));
            if (candidate.length() == 5 && !candidate.endsWith("s")) return candidate;
        }
        throw new IllegalStateException("Unable to select a secret word from the dictionary.");
    }

    private static boolean matchesDifficulty(String word, Difficulty difficulty) {
        int vowels = countVowels(word);
        boolean hasDouble = hasDoubleLetter(word);

        return switch (difficulty) {
            case NORMAL -> vowels >= 2;                 // "more vowels"
            case HARD -> vowels <= 1 && !hasDouble;     // few vowels, no doubles
            case EXPERT -> vowels <= 1;                 // few/no vowels, doubles allowed
        };
    }

    private static int countVowels(String word) {
        int count = 0;
        for (int i = 0; i < word.length(); i++) {
            if (VOWELS.contains(word.charAt(i))) count++;
        }
        return count;
    }

    private static boolean hasDoubleLetter(String word) {
        for (int i = 1; i < word.length(); i++) {
            if (word.charAt(i) == word.charAt(i - 1)) return true;
        }
        return false;
    }
}
