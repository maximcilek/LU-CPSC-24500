package com.example.wordgolf.ui;

import com.example.wordgolf.domain.TileMark;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Visual grid of guesses: rows x columns (typically 6 x 5).
 */
public final class GuessGrid {

    private final int rows;
    private final int cols;

    private final GridPane root = new GridPane();
    private final List<List<Tile>> tiles = new ArrayList<>();

    public GuessGrid(int rows, int cols) {
        if (rows <= 0 || cols <= 0) throw new IllegalArgumentException("rows/cols must be > 0");
        this.rows = rows;
        this.cols = cols;

        root.setHgap(8);
        root.setVgap(8);
        root.setPadding(new Insets(10));
        root.setAlignment(Pos.CENTER);

        for (int r = 0; r < rows; r++) {
            List<Tile> row = new ArrayList<>();
            for (int c = 0; c < cols; c++) {
                Tile tile = new Tile();
                row.add(tile);
                root.add(tile.root, c, r);
            }
            tiles.add(row);
        }
        root.getStyleClass().add("guess-grid");
    }

    public Parent getRoot() { return root; }

    public int rows() { return rows; }
    public int cols() { return cols; }

    public void clearAll() {
        for (List<Tile> row : tiles) {
            for (Tile t : row) {
                t.setLetter(' ');
                t.setMark(TileMark.NEUTRAL);
            }
        }
    }

    public void setRowText(int rowIndex, String text) {
        Objects.checkIndex(rowIndex, rows);
        String t = (text == null) ? "" : text;
        for (int c = 0; c < cols; c++) {
            char ch = c < t.length() ? t.charAt(c) : ' ';
            tiles.get(rowIndex).get(c).setLetter(ch);
        }
    }

    public void setRowMarks(int rowIndex, List<TileMark> marks) {
        Objects.checkIndex(rowIndex, rows);
        if (marks == null || marks.size() != cols) throw new IllegalArgumentException("marks must have size " + cols);
        for (int c = 0; c < cols; c++) {
            tiles.get(rowIndex).get(c).setMark(marks.get(c));
        }
    }

    public void lockRow(int rowIndex) {
        Objects.checkIndex(rowIndex, rows);
        for (int c = 0; c < cols; c++) {
            tiles.get(rowIndex).get(c).root.getStyleClass().add("tile-locked");
        }
    }

    private static final class Tile {
        private final StackPane root = new StackPane();
        private final Label label = new Label(" ");

        Tile() {
            root.setMinSize(58, 58);
            root.setPrefSize(58, 58);
            root.setMaxSize(58, 58);
            root.getStyleClass().add("tile");

            label.getStyleClass().add("tile-text");
            root.getChildren().add(label);
        }

        void setLetter(char ch) {
            label.setText(Character.isLetter(ch) ? String.valueOf(Character.toUpperCase(ch)) : " ");
        }

        void setMark(TileMark mark) {
            root.getStyleClass().removeAll("tile-neutral", "tile-gray", "tile-yellow", "tile-green");
            String style = switch (mark) {
                case NEUTRAL -> "tile-neutral";
                case GRAY -> "tile-gray";
                case YELLOW -> "tile-yellow";
                case GREEN -> "tile-green";
            };
            root.getStyleClass().add(style);
        }
    }
}
