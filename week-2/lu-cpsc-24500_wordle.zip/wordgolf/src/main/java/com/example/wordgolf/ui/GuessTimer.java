package com.example.wordgolf.ui;

import javafx.application.Platform;

import java.util.Objects;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Per-guess countdown timer.
 */
public final class GuessTimer implements AutoCloseable {

    private final ScheduledExecutorService executor;
    private ScheduledFuture<?> task;

    public GuessTimer() {
        this.executor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "wordgolf-timer");
            t.setDaemon(true);
            return t;
        });
    }

    /**
     * Starts a new countdown and calls callbacks on the JavaFX thread.
     * @param seconds total seconds
     * @param onTick receives remaining seconds (including 0)
     * @param onExpired called once when timer reaches 0
     */
    public void start(int seconds, java.util.function.IntConsumer onTick, Runnable onExpired) {
        Objects.requireNonNull(onTick, "onTick");
        Objects.requireNonNull(onExpired, "onExpired");
        stop();

        AtomicInteger remaining = new AtomicInteger(seconds);
        Platform.runLater(() -> onTick.accept(remaining.get()));

        task = executor.scheduleAtFixedRate(() -> {
            int r = remaining.decrementAndGet();
            Platform.runLater(() -> onTick.accept(Math.max(0, r)));

            if (r <= 0) {
                stop();
                Platform.runLater(onExpired);
            }
        }, 1, 1, TimeUnit.SECONDS);
    }

    /**
     * Stops any running countdown.
     */
    public void stop() {
        if (task != null) {
            task.cancel(false);
            task = null;
        }
    }

    @Override
    public void close() {
        stop();
        executor.shutdownNow();
    }
}
