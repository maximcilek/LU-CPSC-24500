package com.example.wordgolf.ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.util.*;
import java.util.function.Consumer;

/**
 * On-screen keyboard for A-Z plus Enter/Backspace.
 */
public final class KeyboardPane {

    private final VBox root = new VBox(8);

    private final Map<String, Button> keys = new HashMap<>();
    private Consumer<String> onKeyPressed = k -> {};

    public KeyboardPane() {
        root.setPadding(new Insets(8));
        root.setAlignment(Pos.CENTER);
        root.getStyleClass().add("keyboard");

        root.getChildren().addAll(
                buildRow("QWERTYUIOP"),
                buildRow("ASDFGHJKL"),
                buildBottomRow()
        );
    }

    private Parent buildRow(String letters) {
        HBox row = new HBox(6);
        row.setAlignment(Pos.CENTER);

        for (char ch : letters.toCharArray()) {
            String key = String.valueOf(ch);
            Button b = new Button(key);
            b.setFocusTraversable(false);
            b.getStyleClass().add("key");
            b.setOnAction(e -> onKeyPressed.accept(key));
            keys.put(key, b);
            row.getChildren().add(b);
        }
        return row;
    }

    private Parent buildBottomRow() {
        HBox row = new HBox(6);
        row.setAlignment(Pos.CENTER);

        Button enter = new Button("Enter");
        enter.setFocusTraversable(false);
        enter.getStyleClass().addAll("key", "key-wide");
        enter.setOnAction(e -> onKeyPressed.accept("ENTER"));
        keys.put("ENTER", enter);

        Button back = new Button("⌫");
        back.setFocusTraversable(false);
        back.getStyleClass().addAll("key", "key-wide");
        back.setOnAction(e -> onKeyPressed.accept("BACKSPACE"));
        keys.put("BACKSPACE", back);

        row.getChildren().add(enter);
        row.getChildren().addAll(buildLetterButtons("ZXCVBNM"));
        row.getChildren().add(back);
        return row;
    }

    private List<Button> buildLetterButtons(String letters) {
        List<Button> list = new ArrayList<>();
        for (char ch : letters.toCharArray()) {
            String key = String.valueOf(ch);
            Button b = new Button(key);
            b.setFocusTraversable(false);
            b.getStyleClass().add("key");
            b.setOnAction(e -> onKeyPressed.accept(key));
            keys.put(key, b);
            list.add(b);
        }
        return list;
    }

    public Parent getRoot() { return root; }

    public void setOnKeyPressed(Consumer<String> handler) {
        this.onKeyPressed = Objects.requireNonNull(handler, "handler");
    }

    public void resetKeyStyles() {
        for (Button b : keys.values()) {
            b.getStyleClass().removeAll("key-gray", "key-yellow", "key-green");
        }
    }

    /**
     * Updates a key color. Priority order: GREEN overrides YELLOW overrides GRAY.
     * @param letter A-Z
     * @param kind "gray" | "yellow" | "green"
     */
    public void updateKeyColor(String letter, String kind) {
        Button b = keys.get(letter.toUpperCase(Locale.ROOT));
        if (b == null) return;

        boolean hasGreen = b.getStyleClass().contains("key-green");
        boolean hasYellow = b.getStyleClass().contains("key-yellow");

        switch (kind) {
            case "green" -> {
                b.getStyleClass().removeAll("key-gray", "key-yellow");
                if (!b.getStyleClass().contains("key-green")) b.getStyleClass().add("key-green");
            }
            case "yellow" -> {
                if (hasGreen) return;
                b.getStyleClass().remove("key-gray");
                if (!b.getStyleClass().contains("key-yellow")) b.getStyleClass().add("key-yellow");
            }
            case "gray" -> {
                if (hasGreen || hasYellow) return;
                if (!b.getStyleClass().contains("key-gray")) b.getStyleClass().add("key-gray");
            }
            default -> { /* ignore */ }
        }
    }
}
