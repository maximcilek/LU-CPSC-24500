package com.example.wordgolf.ui;

import com.example.wordgolf.domain.Difficulty;
import com.example.wordgolf.domain.GameConfig;
import com.example.wordgolf.domain.GameMode;
import com.example.wordgolf.domain.TileMark;
import com.example.wordgolf.game.GameEngine;
import com.example.wordgolf.game.GuessEvaluation;
import com.example.wordgolf.game.RoundState;
import com.example.wordgolf.game.ScoreBoard;
import com.example.wordgolf.services.DefaultGuessEvaluator;
import com.example.wordgolf.services.DictionaryService;
import com.example.wordgolf.services.SecretWordService;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;

/**
 * Orchestrates UI interaction and game logic.
 */
public final class MainController {

    private final MainView view;
    private final DictionaryService dictionaryService;
    private final SecretWordService secretWordService;

    private final GameEngine engine = new GameEngine(new DefaultGuessEvaluator(), 6);
    private final ScoreBoard scoreBoard = new ScoreBoard();
    private final GuessTimer timer = new GuessTimer();

    private final StringBuilder currentInput = new StringBuilder(5);

    public MainController(MainView view, DictionaryService dictionaryService, SecretWordService secretWordService) {
        this.view = Objects.requireNonNull(view, "view");
        this.dictionaryService = Objects.requireNonNull(dictionaryService, "dictionaryService");
        this.secretWordService = Objects.requireNonNull(secretWordService, "secretWordService");
    }

    /**
     * Initializes wiring and starts the first round.
     */
    public void initialize() {
        view.keyboardPane().setOnKeyPressed(this::handleKeyToken);
        view.newRoundButton().setOnAction(e -> startNewRound());
        view.giveUpButton().setOnAction(e -> giveUpRound());

        // Physical keyboard support
        view.getRoot().addEventFilter(KeyEvent.KEY_PRESSED, this::handlePhysicalKeyPressed);

        startNewRound();
    }

    private void startNewRound() {
        timer.stop();
        currentInput.setLength(0);

        GameConfig config = new GameConfig(view.difficultyCombo().getValue(), view.modeCombo().getValue());
        String secret = secretWordService.pickSecret(config.difficulty());
        engine.startNewRound(secret, config);

        view.guessGrid().clearAll();
        view.keyboardPane().resetKeyStyles();
        view.hintLabel().setText("Round started. Enter a 5-letter word.");
        updateScoreLabel();
        startTimerIfNeeded();
        refreshInputRow();
    }

    private void giveUpRound() {
        if (engine.getState() != RoundState.IN_PROGRESS) return;

        Optional<ButtonType> result = new Alert(Alert.AlertType.CONFIRMATION,
                "Give up and reveal the word? This scores 7 points.",
                ButtonType.CANCEL, ButtonType.OK).showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            timer.stop();
            engine.giveUp();
            endRoundAndScore();
        }
    }

    private void handlePhysicalKeyPressed(KeyEvent e) {
        if (e.getCode() == KeyCode.ENTER) {
            handleKeyToken("ENTER");
            e.consume();
        } else if (e.getCode() == KeyCode.BACK_SPACE) {
            handleKeyToken("BACKSPACE");
            e.consume();
        } else {
            String text = e.getText();
            if (text != null && text.length() == 1) {
                char ch = text.charAt(0);
                if (Character.isLetter(ch)) {
                    handleKeyToken(String.valueOf(Character.toUpperCase(ch)));
                    e.consume();
                }
            }
        }
    }

    private void handleKeyToken(String token) {
        if (engine.getState() != RoundState.IN_PROGRESS) return;

        switch (token) {
            case "ENTER" -> submitIfComplete();
            case "BACKSPACE" -> backspace();
            default -> {
                if (token.length() == 1 && Character.isLetter(token.charAt(0))) addLetter(token.charAt(0));
            }
        }
    }

    private void addLetter(char ch) {
        if (currentInput.length() >= 5) return;
        currentInput.append(Character.toLowerCase(ch));
        refreshInputRow();
    }

    private void backspace() {
        if (currentInput.isEmpty()) return;
        currentInput.deleteCharAt(currentInput.length() - 1);
        refreshInputRow();
    }

    private void submitIfComplete() {
        if (currentInput.length() < 5) {
            view.hintLabel().setText("Not enough letters.");
            return;
        }

        String guess = currentInput.toString().toLowerCase(Locale.ROOT);
        if (!dictionaryService.isValidGuess(guess)) {
            view.hintLabel().setText("Not a valid 5-letter English word (dictionary check).");
            return;
        }

        try {
            GuessEvaluation eval = engine.submitGuess(guess);
            int row = engine.getAttemptIndex() - 1;

            view.guessGrid().setRowText(row, guess);
            view.guessGrid().setRowMarks(row, eval.marks());
            view.guessGrid().lockRow(row);

            updateKeyboardColors(guess, eval.marks());

            // Host feedback: counts only, no letters revealed
            view.hintLabel().setText("Host: " + eval.greenCount() + " green, " + eval.yellowCount() + " yellow.");

            currentInput.setLength(0);
            refreshInputRow();

            if (engine.getState() != RoundState.IN_PROGRESS) {
                timer.stop();
                endRoundAndScore();
            } else {
                // Next guess begins; restart timer for timed modes
                startTimerIfNeeded();
            }
        } catch (IllegalStateException ex) {
            view.hintLabel().setText(ex.getMessage());
        }
    }

    private void updateKeyboardColors(String guess, List<TileMark> marks) {
        for (int i = 0; i < 5; i++) {
            String letter = String.valueOf(Character.toUpperCase(guess.charAt(i)));
            TileMark m = marks.get(i);
            switch (m) {
                case GREEN -> view.keyboardPane().updateKeyColor(letter, "green");
                case YELLOW -> view.keyboardPane().updateKeyColor(letter, "yellow");
                case GRAY -> view.keyboardPane().updateKeyColor(letter, "gray");
                case NEUTRAL -> { /* uncovered */ }
            }
        }
    }

    private void startTimerIfNeeded() {
        GameMode mode = engine.getConfig().mode();
        if (!mode.isTimed()) {
            view.timerLabel().setText("—");
            return;
        }
        int seconds = mode.secondsPerGuess();
        timer.start(seconds,
                remaining -> view.timerLabel().setText("Time: " + remaining + "s"),
                this::handleTimeout);
    }

    private void handleTimeout() {
        if (engine.getState() != RoundState.IN_PROGRESS) return;

        int row = engine.getAttemptIndex();
        view.guessGrid().setRowText(row, currentInput.toString());
        view.guessGrid().lockRow(row);
        view.hintLabel().setText("Time expired. Attempt used.");

        currentInput.setLength(0);
        engine.timeoutAttempt();

        if (engine.getState() != RoundState.IN_PROGRESS) {
            endRoundAndScore();
        } else {
            refreshInputRow();
            startTimerIfNeeded();
        }
    }

    private void refreshInputRow() {
        if (engine.getState() != RoundState.IN_PROGRESS) return;
        int row = engine.getAttemptIndex();
        if (row < 0 || row >= engine.getMaxAttempts()) return;

        // Don't overwrite previous locked rows; only the current row.
        view.guessGrid().setRowText(row, currentInput.toString());
    }

    private void endRoundAndScore() {
        String secret = engine.getSecret();
        int points = switch (engine.getState()) {
            case SOLVED -> engine.getHistory().size();
            case FAILED, GAVE_UP -> 7;
            default -> 7;
        };
        scoreBoard.addRound(points);
        updateScoreLabel();

        String header = switch (engine.getState()) {
            case SOLVED -> "Solved!";
            case FAILED -> "Out of attempts!";
            case GAVE_UP -> "Gave up!";
            default -> "Round over!";
        };

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Round Result");
        alert.setHeaderText(header);
        alert.setContentText("The word was: " + secret.toUpperCase(Locale.ROOT)
                + "\nRound score: " + points
                + "\nTotal score: " + scoreBoard.getTotalScore()
                + " (" + scoreBoard.getRoundsPlayed() + " rounds)");
        alert.showAndWait();

        view.hintLabel().setText("Click New Round to play again.");
        view.timerLabel().setText("—");
    }

    private void updateScoreLabel() {
        view.scoreLabel().setText("Score: " + scoreBoard.getTotalScore()
                + " (" + scoreBoard.getRoundsPlayed() + " rounds)");
    }
}
