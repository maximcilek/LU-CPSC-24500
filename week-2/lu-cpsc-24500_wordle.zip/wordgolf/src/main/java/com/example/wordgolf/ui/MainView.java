package com.example.wordgolf.ui;

import com.example.wordgolf.domain.Difficulty;
import com.example.wordgolf.domain.GameMode;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;

/**
 * Main view (UI composition only). Event wiring is handled by {@link MainController}.
 */
public final class MainView {

    private final BorderPane root = new BorderPane();

    private final ComboBox<Difficulty> difficultyCombo = new ComboBox<>();
    private final ComboBox<GameMode> modeCombo = new ComboBox<>();
    private final Label timerLabel = new Label("—");
    private final Label scoreLabel = new Label("Score: 0 (0 rounds)");
    private final Label hintLabel = new Label("Type using on-screen keyboard or physical keyboard.");

    private final Button newRoundButton = new Button("New Round");
    private final Button giveUpButton = new Button("Give Up");

    private final GuessGrid guessGrid = new GuessGrid(6, 5);
    private final KeyboardPane keyboardPane = new KeyboardPane();

    public MainView() {
        root.setPadding(new Insets(16));
        root.setTop(buildTopBar());
        root.setCenter(buildCenter());
        root.setBottom(buildBottom());
        BorderPane.setMargin(root.getBottom(), new Insets(12, 0, 0, 0));

        hintLabel.getStyleClass().add("hint");
        timerLabel.getStyleClass().add("timer");
        scoreLabel.getStyleClass().add("score");

        root.getStyleClass().add("app-root");
    }

    private Parent buildTopBar() {
        difficultyCombo.getItems().setAll(Difficulty.values());
        difficultyCombo.setValue(Difficulty.NORMAL);

        modeCombo.getItems().setAll(GameMode.values());
        modeCombo.setValue(GameMode.NORMAL);

        Label title = new Label("Word Golf");
        title.setFont(Font.font(22));
        title.getStyleClass().add("title");

        HBox left = new HBox(12, title, new Separator(javafx.geometry.Orientation.VERTICAL),
                new Label("Difficulty:"), difficultyCombo,
                new Label("Mode:"), modeCombo);
        left.setAlignment(Pos.CENTER_LEFT);

        VBox right = new VBox(4, timerLabel, scoreLabel);
        right.setAlignment(Pos.CENTER_RIGHT);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox top = new HBox(16, left, spacer, right);
        top.setAlignment(Pos.CENTER_LEFT);
        top.setPadding(new Insets(0, 0, 10, 0));
        top.getStyleClass().add("topbar");
        return top;
    }

    private Parent buildCenter() {
        VBox box = new VBox(12, guessGrid.getRoot(), hintLabel);
        box.setAlignment(Pos.TOP_CENTER);
        VBox.setVgrow(guessGrid.getRoot(), Priority.NEVER);
        return box;
    }

    private Parent buildBottom() {
        HBox buttons = new HBox(12, newRoundButton, giveUpButton);
        buttons.setAlignment(Pos.CENTER);

        VBox bottom = new VBox(10, keyboardPane.getRoot(), buttons);
        bottom.setAlignment(Pos.CENTER);
        return bottom;
    }

    public Parent getRoot() { return root; }

    public ComboBox<Difficulty> difficultyCombo() { return difficultyCombo; }
    public ComboBox<GameMode> modeCombo() { return modeCombo; }

    public Label timerLabel() { return timerLabel; }
    public Label scoreLabel() { return scoreLabel; }
    public Label hintLabel() { return hintLabel; }

    public Button newRoundButton() { return newRoundButton; }
    public Button giveUpButton() { return giveUpButton; }

    public GuessGrid guessGrid() { return guessGrid; }
    public KeyboardPane keyboardPane() { return keyboardPane; }

    public void requestKeyboardFocus() {
        root.requestFocus();
    }
}
