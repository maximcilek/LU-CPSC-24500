module com.example.wordgolf {
    requires javafx.controls;
    requires javafx.graphics;

    exports com.example.wordgolf;
    exports com.example.wordgolf.domain;
    exports com.example.wordgolf.game;
    exports com.example.wordgolf.services;
    exports com.example.wordgolf.ui;
}
