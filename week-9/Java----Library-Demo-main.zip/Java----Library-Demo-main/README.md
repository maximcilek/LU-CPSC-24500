# LibraryDemo
Java application to be converted to Python
