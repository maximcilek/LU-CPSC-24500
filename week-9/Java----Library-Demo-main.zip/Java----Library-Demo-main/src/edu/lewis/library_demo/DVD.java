package edu.lewis.library_demo;

public class DVD extends LibraryItem {
    private int duration;

    public DVD(String title, String itemId, int duration) {
        super(title, itemId);
        this.duration = duration;
    }

    public int getDuration() {
        return duration;
    }

    @Override
    public String toString() {
        return super.toString() +
               "\nDuration: " + duration + " minutes";
    }
}
