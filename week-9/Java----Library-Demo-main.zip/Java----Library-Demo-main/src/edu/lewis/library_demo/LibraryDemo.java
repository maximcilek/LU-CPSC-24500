package edu.lewis.library_demo;

public class LibraryDemo {
    public static void main(String[] args) {
        Book book1 = new Book("The Hobbit", "B101", "J.R.R. Tolkien");
        DVD dvd1 = new DVD("Inception", "D202", 148);

        System.out.println("Book Information:");
        System.out.println(book1);
        System.out.println();

        System.out.println("DVD Information:");
        System.out.println(dvd1);
        System.out.println();

        if (book1.checkOut()) {
            System.out.println(book1.getTitle() + " has been checked out.");
        } else {
            System.out.println(book1.getTitle() + " is already checked out.");
        }

        if (book1.checkOut()) {
            System.out.println(book1.getTitle() + " has been checked out.");
        } else {
            System.out.println(book1.getTitle() + " is already checked out.");
        }

        if (book1.returnItem()) {
            System.out.println(book1.getTitle() + " has been returned.");
        } else {
            System.out.println(book1.getTitle() + " was not checked out.");
        }

        System.out.println();

        if (dvd1.checkOut()) {
            System.out.println(dvd1.getTitle() + " has been checked out.");
        } else {
            System.out.println(dvd1.getTitle() + " is already checked out.");
        }

        System.out.println();
        System.out.println("Updated DVD Information:");
        System.out.println(dvd1);
    }
}
