package edu.lewis.library_demo;

public class LibraryItem {
    private String title;
    private String itemId;
    private boolean checkedOut;

    public LibraryItem(String title, String itemId) {
        this.title = title;
        this.itemId = itemId;
        this.checkedOut = false;
    }

    public String getTitle() {
        return title;
    }

    public String getItemId() {
        return itemId;
    }

    public boolean isCheckedOut() {
        return checkedOut;
    }

    public boolean checkOut() {
        if (!checkedOut) {
            checkedOut = true;
            return true;
        }
        return false;
    }

    public boolean returnItem() {
        if (checkedOut) {
            checkedOut = false;
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Title: " + title +
               "\nItem ID: " + itemId +
               "\nChecked Out: " + checkedOut;
    }
}
